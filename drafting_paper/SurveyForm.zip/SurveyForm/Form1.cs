﻿using System;
using System.Windows.Forms;

namespace SurveyForm
{
    public partial class Form1 : Form
    {
        private SurveyForm.Form3 Click;

        public Form1()
        {
            InitializeComponent();
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if(radioButton1.Checked == true)
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;  //표지창 꺼짐

            Form3 showForm3 = new Form3();

            showForm3.ShowDialog(); //내용창 두둥탁
        }
    }
}

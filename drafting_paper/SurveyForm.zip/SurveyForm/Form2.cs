﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SurveyForm
{
    public partial class Form2 : Form
    {
        private SurveyForm.Form1 Click;

        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;  //표지창 꺼짐

            Form1 showForm1 = new Form1();

            showForm1.ShowDialog(); //내용창 두둥탁
         }
    }
}

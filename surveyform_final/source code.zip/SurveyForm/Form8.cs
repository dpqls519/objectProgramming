﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace SurveyForm
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }   


        //qna에 있는 데이터들 조회
        private void view_Click(object sender, EventArgs e)
        {
            string connection = "Server=localhost;Port=3306;Database=add;Uid=root;Pwd=";
            MySqlConnection con = new MySqlConnection(connection);
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM qna";

            try
            {
                con.Open();
                MySqlDataReader table = cmd.ExecuteReader();

                for (int i = 0; table.Read(); i++)
                {
                    dataGridView1.Rows.Add();
                    dataGridView1.Rows[i].Cells["question"].Value = table["question"].ToString();
                    dataGridView1.Rows[i].Cells["answer"].Value = table["answer"].ToString();
                }
            }
            catch (Exception ex)
            {
                return;
            }
            finally
            {
                con.Close();
            }
        }

        //홈으로
        private void home_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("홈으로 돌아가시겠습니까?", "Attention", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Visible = false;  //항목조회페이지 꺼짐
                Form1 showForm1 = new Form1();
                showForm1.ShowDialog(); //표지창
            }
        }
    }
}

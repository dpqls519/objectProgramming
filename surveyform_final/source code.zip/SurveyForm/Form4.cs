﻿using System;
using System.Windows.Forms;

namespace SurveyForm
{
    public partial class Form4 : Form
    {
        string satisfaction4;

        public Form4()
        {
            InitializeComponent();
        }

        //다음으로
        private void next_Click(object sender, EventArgs e)
        {
            //textbox가 빈값이라면 메시지박스로 안내
            if (String.IsNullOrWhiteSpace(lack.Text) || String.IsNullOrWhiteSpace(want.Text))
            {
                MessageBox.Show("답을 입력해주세요");
            }
            else
            {
                //각 button에 값 할당
                if (radioButton1.Checked == true) satisfaction4 = "매우 불만족";
                else if (radioButton2.Checked == true) satisfaction4 = "약간 불만족";
                else if (radioButton3.Checked == true) satisfaction4 = "약간 만족";
                else if (radioButton4.Checked == true) satisfaction4 = "매우 만족";

                //Form5에 data값 전달
                Form5.satisfaction = satisfaction4;
                Form5.lack = lack.Text;
                Form5.want = want.Text;

                this.Visible = false;  //2페이지 꺼짐
                Form5 showForm5 = new Form5();
                showForm5.ShowDialog(); //3페이지
            }
        }

        //이전으로
        private void previous_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("이전으로 돌아가시겠습니까?", "Attention", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Visible = false;  //2페이지 꺼짐
                Form3 showForm3 = new Form3();
                showForm3.ShowDialog(); //1페이지
            }
        }

        //홈으로
        private void home_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("홈으로 돌아가시겠습니까?", "Attention", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Visible = false;  //2페이지 꺼짐
                Form1 showForm1 = new Form1();
                showForm1.ShowDialog(); //표지
            }
        }

    }
}
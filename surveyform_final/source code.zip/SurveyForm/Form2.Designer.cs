﻿namespace SurveyForm
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.college = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.major = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.satisfaction = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lack = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.want = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.duration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.participation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.home = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("함초롬바탕", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button1.Location = new System.Drawing.Point(564, 10);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 36);
            this.button1.TabIndex = 32;
            this.button1.Text = "조회";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.college,
            this.major,
            this.grade,
            this.satisfaction,
            this.lack,
            this.want,
            this.duration,
            this.participation});
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView1.Location = new System.Drawing.Point(10, 50);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(681, 353);
            this.dataGridView1.TabIndex = 33;
            // 
            // college
            // 
            this.college.HeaderText = "college";
            this.college.MinimumWidth = 6;
            this.college.Name = "college";
            this.college.Width = 125;
            // 
            // major
            // 
            this.major.HeaderText = "major";
            this.major.MinimumWidth = 6;
            this.major.Name = "major";
            this.major.Width = 200;
            // 
            // grade
            // 
            this.grade.HeaderText = "grade";
            this.grade.MinimumWidth = 6;
            this.grade.Name = "grade";
            this.grade.Width = 125;
            // 
            // satisfaction
            // 
            this.satisfaction.HeaderText = "satisfaction";
            this.satisfaction.MinimumWidth = 6;
            this.satisfaction.Name = "satisfaction";
            this.satisfaction.Width = 125;
            // 
            // lack
            // 
            this.lack.HeaderText = "lack";
            this.lack.MinimumWidth = 6;
            this.lack.Name = "lack";
            this.lack.Width = 500;
            // 
            // want
            // 
            this.want.HeaderText = "want";
            this.want.MinimumWidth = 6;
            this.want.Name = "want";
            this.want.Width = 500;
            // 
            // duration
            // 
            this.duration.HeaderText = "duration";
            this.duration.MinimumWidth = 6;
            this.duration.Name = "duration";
            this.duration.Width = 200;
            // 
            // participation
            // 
            this.participation.HeaderText = "participation";
            this.participation.MinimumWidth = 6;
            this.participation.Name = "participation";
            this.participation.Width = 125;
            // 
            // home
            // 
            this.home.Font = new System.Drawing.Font("함초롬바탕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.home.Location = new System.Drawing.Point(10, 10);
            this.home.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.home.Name = "home";
            this.home.Size = new System.Drawing.Size(88, 32);
            this.home.TabIndex = 34;
            this.home.Text = "홈 화면";
            this.home.UseVisualStyleBackColor = true;
            this.home.Click += new System.EventHandler(this.home_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 414);
            this.Controls.Add(this.home);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn college;
        private System.Windows.Forms.DataGridViewTextBoxColumn major;
        private System.Windows.Forms.DataGridViewTextBoxColumn grade;
        private System.Windows.Forms.DataGridViewTextBoxColumn satisfaction;
        private System.Windows.Forms.DataGridViewTextBoxColumn lack;
        private System.Windows.Forms.DataGridViewTextBoxColumn want;
        private System.Windows.Forms.DataGridViewTextBoxColumn duration;
        private System.Windows.Forms.DataGridViewTextBoxColumn participation;
        private System.Windows.Forms.Button home;
    }
}
﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace SurveyForm
{
    public partial class Form3 : Form
    {
        string college3;
        int grade3 = 0;

        public Form3()
        {
            InitializeComponent();
        }

        //다음으로
        private void next_Click(object sender, EventArgs e)
        {
            //textbox가 빈값이라면 메시지박스로 안내
            if (String.IsNullOrWhiteSpace(major.Text))
            {
                MessageBox.Show("답을 입력해주세요");
            }
            else 
            { 
            //각 button에 값 할당
            if (radioButton1.Checked == true) college3 = "문과대";
            else if (radioButton2.Checked == true) college3 = "법정대";
            else if (radioButton3.Checked == true) college3 = "상경대";
            else if (radioButton4.Checked == true) college3 = "이과대";
            else if (radioButton5.Checked == true) college3 = "공과대";
            else if (radioButton6.Checked == true) college3 = "예종대";
            else if (radioButton7.Checked == true) college3 = "약학대";
            else if (radioButton8.Checked == true) college3 = "신학대";

            //각 button에 값 할당
            if (radioButton9.Checked == true) grade3 = 1;
            else if (radioButton10.Checked == true) grade3 = 2;
            else if (radioButton11.Checked == true) grade3 = 3;
            else if (radioButton12.Checked == true) grade3 = 4;
            else if (radioButton13.Checked == true) grade3 = 5;

            //Form5에 data값 전달
            Form5.college = college3;
            Form5.grade = grade3;
            Form5.major = major.Text;

            this.Visible = false;  //2페이지 꺼짐
            Form4 showForm4 = new Form4();
            showForm4.ShowDialog(); //3페이지
            }
        }

        //홈으로
        private void home_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("홈으로 돌아가시겠습니까?", "Attention", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Visible = false;  //2페이지 꺼짐
                Form1 showForm1 = new Form1();
                showForm1.ShowDialog(); //표지창
            }
        }
    }
}
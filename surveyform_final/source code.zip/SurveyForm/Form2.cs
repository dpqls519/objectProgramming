﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace SurveyForm
{
    public partial class Form2 : Form
    {
        MySqlConnection connection =
        new MySqlConnection("Server=localhost;Database=survey;Uid=root;Pwd=;");

        public Form2()
        {
            InitializeComponent();
        }

        //조회 버튼 클릭시 SQL에서 데이터 조회
        private void button1_Click(object sender, EventArgs e)
        {
            string connection = "Server=localhost;Port=3306;Database=survey;Uid=root;Pwd=";
            MySqlConnection con = new MySqlConnection(connection);
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM answer";

            try
            {
                con.Open();
                MySqlDataReader table = cmd.ExecuteReader();

                for (int i = 0; table.Read(); i++)
                {
                    dataGridView1.Rows.Add();
                    dataGridView1.Rows[i].Cells["college"].Value = table["college"].ToString();
                    dataGridView1.Rows[i].Cells["major"].Value = table["major"].ToString();
                    dataGridView1.Rows[i].Cells["grade"].Value = table["grade"].ToString();
                    dataGridView1.Rows[i].Cells["satisfaction"].Value = table["satisfaction"].ToString();
                    dataGridView1.Rows[i].Cells["lack"].Value = table["lack"].ToString();
                    dataGridView1.Rows[i].Cells["want"].Value = table["want"].ToString();
                    dataGridView1.Rows[i].Cells["duration"].Value = table["duration"].ToString();
                    dataGridView1.Rows[i].Cells["participation"].Value = table["participation"].ToString();
                }
            }
            catch (Exception ex)
            {
                return;
            }
            finally
            {
                con.Close();
            }
        }

        //홈화면 버튼 클릭시
        private void home_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("홈으로 돌아가시겠습니까?", "Attention", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Visible = false;  //3페이지 꺼짐
                Form1 showForm1 = new Form1();
                showForm1.ShowDialog(); //표지
            }
        }
    }
}

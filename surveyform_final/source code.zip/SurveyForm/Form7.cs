﻿using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace SurveyForm
{
    public partial class Form7 : Form
    {
        public string addtext, question, answer;
        public int num = 0,x = 0;
        Label[] label = new Label[3];
        TextBox[] textBox = new TextBox[3];

        public Form7()
        {
            InitializeComponent();
        }

        //label 동적 생성
        public void settingques()
        {
            label[num] = new Label();
            label[num].Location = new Point(30, 10 + (40 * (1+x)));
            label[num].Size = new Size(500, 30);
            label[num].Text = "" + addtext;
            groupBox1.Controls.Add(label[num]);
        }

        //textbox 동적생성
        public void settingansw()
        {
            textBox[num] = new TextBox();
            textBox[num].Location = new Point(30, 10 + (40 * (2 + x)));
            textBox[num].Size = new Size(500, 30);
            groupBox1.Controls.Add(textBox[num]);
            
        }

        //새로 추가한 질문과 답변을 업로드 하는 함수
        public void upload_add()
        {
            MySqlConnection connection =
                new MySqlConnection("Server=localhost;Database=add;Uid=root;Pwd=;");
            for(int i = 0; i < num; i++) 
            {
                question = label[i].Text;
                answer = textBox[i].Text;

                //칼럼에 추가하는 쿼리문 insertQuery
                string insertQuery = "INSERT INTO qna(question, answer) VALUES" +
                    "(" + "\"" + question + "\"" + "," + "\"" + answer + "\"" + ")";
                //테이블 qna에 항목들을 추가한다
            
            connection.Open();
                MySqlCommand command = new MySqlCommand(insertQuery, connection);
            
            try//예외 처리
            {
                // 만약에 내가처리한 Mysql에 정상적으로 들어지 않았다면 메세지를 보여주라는 뜻이다
                if (command.ExecuteNonQuery() != 1)
                {
                    MessageBox.Show("오류");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            connection.Close();
            }
        }

        //업로드 버튼클릭
        private void upload_Click(object sender, EventArgs e)
        {
            upload_add();
            MessageBox.Show("업로드 완료");
            this.Close();
        }
    }
}

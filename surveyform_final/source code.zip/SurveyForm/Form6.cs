﻿using System;
using System.Windows.Forms;

namespace SurveyForm
{
    public partial class Form6 : Form
    {
        Form7 showForm7 = new Form7();                     
        Boolean open = false;                               //폼 화면 중복 생성 방지 boolean 부여
        public string answer;

        public Form6()
        {
            InitializeComponent();
        }

        private void add_Click(object sender, EventArgs e)
        {
            showForm7.addtext = textBox1.Text;              //text값 form7.addtext에 할당

            //num값이 3이하일 시 실행
            if(showForm7.num <= 2) { 
                if (open == false)
                {
                    open = true;                            //boolean값 변경 후, 폼 화면 중복 생성 방지
                    showForm7.settingques();                //form7에 있는 label 동적 생성 함수 실행  
                    showForm7.settingansw();                //form7에 있는 texbox 동적 생성 함수 실행 
                    showForm7.Show();                       //form6 켜진 상태에서 form7 show
                    showForm7.num += 1;                     //form7에 있는 num값, 값을 하나하나 저장하기 위함
                    showForm7.x += 2;                       //동적생성 위치변경 값
                }
                else
                {
                    showForm7.settingques();                //form7에 있는 label 동적 생성 함수 실행 
                    showForm7.settingansw();                //form7에 있는 texbox 동적 생성 함수 실행 
                    showForm7.Refresh();                    //추가한 질문 페이지 refresh                    
                    showForm7.num += 1;                     //form7에 있는 num값, 값을 하나하나 저장하기 위함
                    showForm7.x += 2;                       //동적생성 위치변경 값
                }
                answer = showForm7.answer;
            }
            else
            {
                MessageBox.Show("3문항 초과", "Attention");  //3문항 초과 메시지 안내
            }
            textBox1.Text = "";                              //동적으로 textbox의 text보낸 후 내용 지움
        }


        //홈으로
        private void home_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("홈으로 돌아가시겠습니까?", "Attention", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Visible = false;                         //항목추가페이지 꺼짐
                showForm7.Visible = false;
                Form1 showForm1 = new Form1();
                showForm1.ShowDialog();                       //표지창
            }
        }
    }
}

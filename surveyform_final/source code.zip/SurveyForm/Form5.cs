﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace SurveyForm
{
    public partial class Form5 : Form
    {
        public static int  grade, participation=0;
        public static string college, major, satisfaction, lack, want, duration;

        public Form5()
        {
            InitializeComponent();
        }

        //항목데이터들을 DB에 업로드하는 함수
        public void upload_db()
        {
            MySqlConnection connection =
                new MySqlConnection("Server=localhost;Database=survey;Uid=root;Pwd=;");

            //칼럼에 추가하는 쿼리문 insertQuery
            string insertQuery = "INSERT INTO answer(college, major, grade, satisfaction, lack, want, duration, participation) VALUES" +
                "(" + "\"" + college +"\""+ "," + "\"" + major + "\"" + "," + grade + "," + "\"" + satisfaction + "\"" + "," + "\"" + lack + "\"" 
                + "," + "\"" + want + "\"" + "," + "\"" + duration + "\"" + "," + participation + ")";
            //테이블 answer에 항목들을 추가한다

            connection.Open();
            MySqlCommand command = new MySqlCommand(insertQuery, connection);

            try//예외 처리
            {
                // 만약에 내가처리한 Mysql에 정상적으로 들어갔다면 메세지를 보여주라는 뜻이다
                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("제출 완료");
                }
                else
                {
                    MessageBox.Show("오류");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            connection.Close();
        }

        //제출하기
        private void submmit_Click(object sender, EventArgs e)
        {
            //textbox가 빈값이라면 메시지박스로 안내
            if (String.IsNullOrWhiteSpace(durationtext.Text))
            {
                MessageBox.Show("답을 입력해주세요");
            }
            else
            {
                //각 button에 값 할당
                if (radioButton1.Checked == true) participation = 1;
                else if (radioButton2.Checked == true) participation = 2;

                duration = durationtext.Text;

                //제출하기전 확인메시지 출력
                if (MessageBox.Show("제출하시겠습니까?", "Attention", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    upload_db();  //upload_db함수 실행
                }

                //제출완료시 홈으로
                this.Visible = false;  //3페이지 꺼짐
                Form1 showForm1 = new Form1();
                showForm1.ShowDialog(); //표지
            }
        }

        //이전으로
        private void previous_Click(object sender, EventArgs e)  
        {
            if (MessageBox.Show("이전으로 돌아가시겠습니까?", "Attention", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Visible = false;  //3페이지 꺼짐
                Form4 showForm4 = new Form4();
                showForm4.ShowDialog(); //2페이지
            }
        }

        //홈으로
        private void home_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("홈으로 돌아가시겠습니까?", "Attention", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Visible = false;  //3페이지 꺼짐
                Form1 showForm1 = new Form1();
                showForm1.ShowDialog(); //표지
            }
        }
    }
}
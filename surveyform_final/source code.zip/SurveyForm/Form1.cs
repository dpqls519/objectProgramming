﻿using System;
using System.Windows.Forms;

namespace SurveyForm
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        //시작하기 버튼 클릭
        private void start_Click(object sender, EventArgs e)
        {
            this.Visible = false;  //표지창 꺼짐
            Form3 showForm3 = new Form3();
            showForm3.ShowDialog(); //1페이지
         }

        //종료하기 버튼 클릭
        private void end_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("종료하시겠습니까?", "Attention", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        //항목추가 버튼 클릭
        private void add_Click(object sender, EventArgs e)
        {
            this.Visible = false;  //표지창 꺼짐
            Form6 showForm6 = new Form6();
            showForm6.ShowDialog(); //항목추가페이지
        }

        //설문결과조회하기 버튼 클릭
        private void view_Click(object sender, EventArgs e)
        {
            this.Visible = false;  //표지창 꺼짐
            Form2 showForm2 = new Form2();
            showForm2.ShowDialog(); //설문결과조회페이지
        }       

        //추가질문조회하기 버튼 클릭
        private void addview_Click(object sender, EventArgs e)
        {
            this.Visible = false;  //표지창 꺼짐
            Form8 showForm8 = new Form8();
            showForm8.ShowDialog(); //추가질문조회페이지
        }
    }
}
